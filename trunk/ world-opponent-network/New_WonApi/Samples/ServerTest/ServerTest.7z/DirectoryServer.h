#include "Server.h"

/* The directory server is basically a a node/folder structured server.  
 * It is used for everything from, holding chatroom informaation
 * to holding Game Patch information.
 * 
 * This server uses Mysql to hold all its 'large' database structure*/

//#define PAYLOAD2  "\x30\x00\x00\x00" "\x45" "\x52\x60" "\x73\x80" "\x90\xA0" "\xB0" "\xC1\xDA\xE0\xF0" "\x01\x00" "\x53" "\x0A\x00" "A u t h S e r v e r " "\x06" "\x00\x00" "\x00\x00\x00\x00"
//typedef unsigned short int UINT16;
//typedef unsigned short int uint16;
//static unsigned char AuthServerPacket[52] = PAYLOAD2;

//#define FlipBytes16(A) ((((uint16)(A) & 0xff00) >> 8) | (((uint16)(A) & 0x00ff) << 8))
//#define hosttobe16(A) FlipBytes16(A)

class DirectoryServer : public Server
{
public:
	DirectoryServer(int port);
	~DirectoryServer();
	int start();
	
private:
	SOCKET listeningSocket;
	char name[100];
	int port;
	static void doConnect(SOCKET socket,DWORD clientIp, char * serverName);
	static unsigned int __stdcall waitForConnections(void * param);
	DWORD externalIp;
};
DWORD WINAPI dirRecv(LPVOID lpParam);
int GetAuthPacket(unsigned char ** packetptr);
//void ChangeServerNetworkAddresses(UINT32 IP, UINT16 Port);