// stdafx.cpp : source file that includes just the standard includes
//	Servertest.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
/*
void Stringtest(char * serverName, int port)
{
	
	char portch[33];
	itoa(port,portch,10);
	int plen = strlen(portch);
	int len = strlen(name);

	char* finalname = name + len - (plen+1);

	printf("String test: The Server name (without port) is %s\n", finalname );
	
}*/