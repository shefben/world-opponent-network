// dbAccess.h: interface for the dbAccess class.
//
//////////////////////////////////////////////////////////////////////
//#include <my_global.h>
//#include <mysql.h>

#if !defined(AFX_DBACCESS_H__3A6FF042_C074_4A3F_AFDC_42575AC2494A__INCLUDED_)
#define AFX_DBACCESS_H__3A6FF042_C074_4A3F_AFDC_42575AC2494A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class dbAccess  
{
public:
	dbAccess();
	virtual ~dbAccess();

};

#endif // !defined(AFX_DBACCESS_H__3A6FF042_C074_4A3F_AFDC_42575AC2494A__INCLUDED_)
